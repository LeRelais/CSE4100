Phase1 program guide

After execution:
	can handle with following codes. type in command you want to use in shell
	  1. builtin commands (quit, history, cd)
	  2. executable files
		2-1. ls
		2-2. cat
		2-3. echo
		2-4. mkdir, rmdir
		2-5. rm
		2-6. etc
		